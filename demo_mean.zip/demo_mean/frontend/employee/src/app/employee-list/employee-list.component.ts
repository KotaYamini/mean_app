import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { WebService } from '../services/web.service';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employeesList: any;
  constructor(private webService: WebService, private router: Router) { }

  ngOnInit() {
    this.getAllEmployees();
  }

  getAllEmployees(){
    this.webService.getAllEmployees().subscribe(
      result => {
        if(result && result.length>0){
          this.employeesList = result;
        }
      }
    )
  }

  deleteEmployee(empData){
    this.webService.deleteEmployees(empData._id).subscribe(
      () => {
          this.getAllEmployees();
      }
    )
  }

  onAddEmployee(){
    this.router.navigate(['/employeeRegistration'])
  }

}
