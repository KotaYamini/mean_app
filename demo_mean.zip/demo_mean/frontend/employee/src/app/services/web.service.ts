import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class WebService {

  private webUrl = 'http://localhost:4000/employees';
  constructor(private http: HttpClient) { }


  getAllEmployees(): Observable<any>{
   const url = `${this.webUrl}`;
   return this.http.get<any>(url);
  }

  getEmployeeById(employeeID: number|string): Observable<any>{
    const url = `${this.webUrl}/${employeeID}`;
    return this.http.get<any>(url);
   }

   createEmployee(body): Observable<any>{
    const url = `${this.webUrl}`;
    return this.http.post<any>(url, body);
   }

   updateEmployee(body): Observable<any>{
    const url = `${this.webUrl}/${body._id}`;
    return this.http.put<any>(url, body);
   }

   deleteEmployees(employeeID: number|string): Observable<any>{
    const url = `${this.webUrl}/${employeeID}`;
    return this.http.delete<any>(url);
   }




}
