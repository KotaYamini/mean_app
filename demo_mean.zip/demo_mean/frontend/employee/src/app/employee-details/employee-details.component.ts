import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';

import { Subscription } from 'rxjs';

import { WebService } from '../services/web.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit, OnDestroy {
 private subscription: Subscription = new  Subscription();
  employeeId: any;
  employeesDetail: any;
  employeeForm: FormGroup;

  constructor(private webService: WebService, private route: ActivatedRoute, private fb: FormBuilder, private router: Router) { }

  ngOnInit() {
  this.employeeForm =  this.fb.group({
      name: [''],
      dob: [''],
      address: [''],
      salary: [''],
      experience: [''],
      role: ['']
    })
    this.subscription.add(this.route.params.subscribe(next => {
      this.employeeId = next['employeeId'];
      this.getEmployeeDetails();
    }))
  }

  onUpdateEmployeeForm(){
    const updateObj = Object.assign({}, this.employeeForm.value);
    updateObj._id = this.employeeId;
    this.webService.updateEmployee(updateObj).subscribe(
      result => {
        if(result && result.length>0){
          this.employeesDetail = result;
          this.router.navigate(['/employeeList']);
        }
      }
    )
  }

  getEmployeeDetails(){
    this.webService.getEmployeeById(this.employeeId).subscribe(
      result => {
        console.log(result);
        if(result && result.length>0){
          this.employeesDetail = result[0];
          this.employeeForm.patchValue({
            name: this.employeesDetail.name,
            dob: this.employeesDetail.dob,
            address: this.employeesDetail.address,
            salary:this.employeesDetail.salary,
            experience: this.employeesDetail.experience,
            role: this.employeesDetail.role,
          })
        }
      }
    )
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}
