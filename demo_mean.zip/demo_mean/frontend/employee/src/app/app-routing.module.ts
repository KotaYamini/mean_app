import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeRegistrationComponent } from './employee-registration/employee-registration.component';

const routes: Routes = [
  {path: 'employeeList', component: EmployeeListComponent},
  {path: 'employeeRegistration', component: EmployeeRegistrationComponent},
  {path: 'employeeDetail/:employeeId', component: EmployeeDetailsComponent},
  { path: '', pathMatch: 'full',  redirectTo: '/employeeList' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
