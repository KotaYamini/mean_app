import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

import { WebService } from '../services/web.service';

@Component({
  selector: 'app-employee-registration',
  templateUrl: './employee-registration.component.html',
  styleUrls: ['./employee-registration.component.css']
})
export class EmployeeRegistrationComponent implements OnInit {
  employeeForm: any;

  constructor(private webService: WebService, private fb: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.employeeForm =  this.fb.group({
      name: [''],
      dob: [''],
      address: [''],
      salary: [''],
      experience: [''],
      role: ['']
    })
  }

  onAddEmployeeForm(){
    const updateObj = Object.assign({}, this.employeeForm.value);
    this.webService.createEmployee(updateObj).subscribe(
      result => {
          this.router.navigate(['/employeeList']);
      }
    )
  }

}
