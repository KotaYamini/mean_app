const express = require('express');

const app = express();

const mongoose = require('./database/mongoose');
const Employee = require('./database/models/employee');


app.use(express.json());
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", '*');
  res.header("Access-Control-Allow-Methods", "GET, POST, HEAD, OPTIONS, PUT,PATCH, DELETE");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});


app.post('/employees',(req,res)=> {
  (new Employee({ 'name':  req.body.name,'dob':  req.body.dob,'address':  req.body.address,'role':  req.body.role,'salary':  req.body.salary, 'experience':  req.body.experience}))
    .save()
    .then((employee) => res.send(employee))
    .catch((error) => console.log(error))
})


app.get('/employees', (req, res) => {
  Employee.find({})
      .then(employees => res.send(employees))
      .catch((error) => console.log(error));
});

app.get('/employees/:employeeId', (req,res) => {
  Employee.find({ _id: req.params.employeeId })
    .then(employees => res.send(employees))
    .catch((error) => console.log(error));
});

app.patch('/employees/:employeeId', (req,res) => {
  Employee.findOneAndUpdate({ _id: req.params.employeeId }, { $set: req.body})
    .then(lists => res.send(lists))
    .catch((error) => console.log(error));
});


app.put('/employees/:employeeId', (req,res) => {
  Employee.findByIdAndUpdate({ _id: req.params.employeeId }, { $set: req.body})
    .then(lists => res.send(lists))
    .catch((error) => console.log(error));
});


app.delete('/employees/:employeeId', (req,res)=> {
  Employee.findByIdAndDelete({  _id: req.params.employeeId}, {$set: req.body})
  .then((task) => res.send(task))
  .catch((error) => console.log(error));
});

const port = process.env.port || 4000;
app.listen(port, ()=>  console.log('Server listened on port' , port));