const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    minlength: 3
  },
  dob: {
    type: String,
    trim: true,
    minlength: 8
  },
  address: {
    type: String,
    trim: true,
    minlength: 5
  },
  role: {
    type: String,
    trim: true,
    minlength: 3
  },
  salary: {
    type: String,
    trim: true,
    minlength: 2
  },
  experience: {
    type: Number,
    trim: true,
    minlength: 1
  }
});

const Employee = mongoose.model('Employee', EmployeeSchema);

module.exports = Employee;